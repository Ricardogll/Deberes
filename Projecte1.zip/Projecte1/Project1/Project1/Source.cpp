#include "SDL.h"
#include<iostream>

#define WINDOW_DIMENSIONS 800

SDL_Rect rectangle;
bool up = false, down = false, right = false, left = false;
SDL_Renderer* renderer;


void Start() {
	SDL_Init(SDL_INIT_EVERYTHING);

	SDL_Window* window;

	window = SDL_CreateWindow("Window", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WINDOW_DIMENSIONS, WINDOW_DIMENSIONS, 0);

	renderer = SDL_CreateRenderer(window, -1, 0);


	SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
	SDL_RenderClear(renderer);
	SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
	rectangle.x = 400;
	rectangle.y = 400;
	rectangle.w = 50;
	rectangle.h = 50;
	SDL_RenderFillRect(renderer, &rectangle);

	// Up until now everything was drawn behind the scenes.
	// This will show the new, red contents of the window.
	SDL_RenderPresent(renderer);

}

bool Input() {
	bool ret = true;
	SDL_Event event;

	while (SDL_PollEvent(&event) != 0)
	{
		if (event.type == SDL_KEYDOWN)
		{
			switch (event.key.keysym.sym)
			{
			case SDLK_UP:
				up = true;
				break;
			case SDLK_DOWN:
				down = true;
				break;
			case SDLK_LEFT:
				left = true;
				break;
			case SDLK_RIGHT:
				right = true;
				break;
			case SDLK_ESCAPE:
				ret = false;
				break;

			}
		}

	}
	return ret;
}

void Move() {
	if (up == true) {
		if (rectangle.y - 10 >= 0) {
			rectangle.y -= 10;
			up = false;
		}
	}
	if (down == true) {
		if ((rectangle.y + 1) + rectangle.h <= WINDOW_DIMENSIONS) {
			rectangle.y += 10;
			down = false;
		}
	}
	if (right == true) {
		if ((rectangle.x + 1) + rectangle.w <= WINDOW_DIMENSIONS) {
			rectangle.x += 10;
			right = false;
		}
	}
	if (left == true) {
		if (rectangle.x - 10 >= 0) {
			rectangle.x -= 10;
			left = false;
		}
	}
}

void Update() {
	SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
	SDL_RenderClear(renderer);
	SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
	SDL_RenderFillRect(renderer, &rectangle);
	SDL_RenderPresent(renderer);
}

int main(int argc, char* args[])
{
	Start();

	while (Input())
	{
		Move();
		Update();
	}


	return false; // EXIT_SUCCESS
}